const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const psService = require('./psService');
const { broadcastEvent } = require('../../config/websocket');
const { optionalAuth } = require('../../middleware/authmiddleware');
const { recordMutation } = require('../security/auditService');
router.use(optionalAuth);
// ========================
// ADMIN: CRUD Themes for an Event
// ========================
// GET all themes for an event (optional ?track=Virtual|Physical)
router.get('/event/:eventId/themes', (req, res) => {
    const track = req.query.track || null;
    psService.getAllThemes(req.params.eventId, track, (err, results) => {
        if (err) return res.status(500).json({ message: 'Failed to fetch themes', error: err.message });
        res.json({ themes: results });
    });
});
// CREATE a theme
router.post('/event/:eventId/themes', (req, res) => {
    const trackVal = String(req.body.Track || req.query.track || 'Virtual').toLowerCase() === 'physical' ? 'Physical' : 'Virtual';
    const payload = { ...req.body, Track: trackVal };
    psService.createTheme(req.params.eventId, payload, (err, result) => {
        if (err) {
            if (err.code === 'ER_DUP_ENTRY') {
                return res.status(409).json({ message: 'A theme with this name already exists for this event track.' });
            }
            return res.status(500).json({ message: 'Failed to create theme', error: err.message });
        }
        recordMutation({
            actor: req.user,
            module: 'problem_statements',
            action: 'CREATE_THEME',
            entityType: 'theme',
            entityId: result?.id,
            eventId: req.params.eventId,
            newState: payload,
            req
        });
        broadcastEvent(req.params.eventId, { type: 'THEMES_UPDATED', eventId: req.params.eventId });
        res.status(201).json(result);
    });
});
// UPDATE a theme
router.put('/themes/:id', (req, res) => {
    psService.updateTheme(req.params.id, req.body, (err) => {
        if (err) return res.status(500).json({ message: 'Failed to update theme', error: err.message });
        broadcastEvent(null, { type: 'THEMES_UPDATED' });
        res.json({ message: 'Theme updated successfully' });
    });
});
// DELETE a theme
router.delete('/themes/:id', (req, res) => {
    psService.deleteTheme(req.params.id, (err) => {
        if (err) return res.status(500).json({ message: 'Failed to delete theme', error: err.message });
        broadcastEvent(null, { type: 'THEMES_UPDATED' });
        res.json({ message: 'Theme deleted successfully' });
    });
});
// ========================
// ADMIN: CRUD Problem Statements for an Event
// ========================
// GET all problem statements for an event (optional ?track=Virtual|Physical)
router.get('/event/:eventId', (req, res) => {
    const track = req.query.track || null;
    psService.getAllByEvent(req.params.eventId, track, (err, results) => {
        if (err) return res.status(500).json({ message: 'Failed to fetch problem statements', error: err.message });
        res.json({ problemStatements: results });
    });
});
// CREATE a problem statement
router.post('/event/:eventId', (req, res) => {
    const trackVal = String(req.body.Track || req.query.track || 'Virtual').toLowerCase() === 'physical' ? 'Physical' : 'Virtual';
    const payload = { ...req.body, Track: trackVal };
    psService.createProblemStatement(req.params.eventId, payload, (err, result) => {
        if (err) {
            if (err.code === 'ER_DUP_ENTRY') {
                return res.status(409).json({ message: 'A problem statement with this code already exists for this event track.' });
            }
            return res.status(500).json({ message: 'Failed to create problem statement', error: err.message });
        }
        recordMutation({
            actor: req.user,
            module: 'problem_statements',
            action: 'CREATE_PROBLEM_STATEMENT',
            entityType: 'problem_statement',
            entityId: result?.id,
            eventId: req.params.eventId,
            newState: payload,
            req
        });
        broadcastEvent(req.params.eventId, { type: 'STATEMENTS_UPDATED', eventId: req.params.eventId });
        res.status(201).json(result);
    });
});
// UPDATE a problem statement
router.put('/:id', (req, res) => {
    psService.updateProblemStatement(req.params.id, req.body, (err) => {
        if (err) return res.status(500).json({ message: 'Failed to update problem statement', error: err.message });
        recordMutation({
            actor: req.user,
            module: 'problem_statements',
            action: 'UPDATE_PROBLEM_STATEMENT',
            entityType: 'problem_statement',
            entityId: req.params.id,
            newState: req.body,
            req
        });
        broadcastEvent(null, { type: 'STATEMENTS_UPDATED' });
        res.json({ message: 'Problem statement updated successfully' });
    });
});
// DELETE a problem statement
router.delete('/:id', (req, res) => {
    psService.deleteProblemStatement(req.params.id, (err) => {
        if (err) return res.status(500).json({ message: 'Failed to delete problem statement', error: err.message });
        recordMutation({
            actor: req.user,
            module: 'problem_statements',
            action: 'DELETE_PROBLEM_STATEMENT',
            entityType: 'problem_statement',
            entityId: req.params.id,
            req
        });
        broadcastEvent(null, { type: 'STATEMENTS_UPDATED' });
        res.json({ message: 'Problem statement deleted successfully' });
    });
});
// ========================
// ADMIN: Publish Controls
// ========================
// GET publish status for an event
router.get('/event/:eventId/publish-status', (req, res) => {
    psService.getPublishStatus(req.params.eventId, (err, result) => {
        if (err) return res.status(500).json({ message: 'Failed to fetch status', error: err.message });
        res.json(result);
    });
});
// Publish/Unpublish Theme
router.put('/event/:eventId/publish-theme', (req, res) => {
    psService.publishTheme(req.params.eventId, req.body.published, (err) => {
        if (err) return res.status(500).json({ message: 'Failed to update theme status', error: err.message });
        recordMutation({
            actor: req.user,
            module: 'problem_statements',
            action: req.body.published ? 'PUBLISH_THEME' : 'UNPUBLISH_THEME',
            entityType: 'theme',
            eventId: req.params.eventId,
            newState: { published: req.body.published },
            req
        });
        broadcastEvent(req.params.eventId, {
            type: 'THEME_PUBLISHED',
            eventId: req.params.eventId,
            published: req.body.published
        });
        res.json({ message: `Theme ${req.body.published ? 'published' : 'unpublished'} successfully` });
    });
});
// Publish/Unpublish Problem Statements
router.put('/event/:eventId/publish-statements', (req, res) => {
    psService.publishProblemStatements(req.params.eventId, req.body.published, (err) => {
        if (err) return res.status(500).json({ message: 'Failed to update status', error: err.message });
        broadcastEvent(req.params.eventId, {
            type: 'STATEMENTS_PUBLISHED',
            eventId: req.params.eventId,
            published: req.body.published
        });
        res.json({ message: `Problem statements ${req.body.published ? 'published' : 'unpublished'} successfully` });
    });
});
// Publish/Unpublish Physical Problem Statements
router.put('/event/:eventId/publish-physical-statements', (req, res) => {
    psService.publishPhysicalProblemStatements(req.params.eventId, req.body.published, (err) => {
        if (err) return res.status(500).json({ message: 'Failed to update physical status', error: err.message });
        broadcastEvent(req.params.eventId, {
            type: 'PHYSICAL_STATEMENTS_PUBLISHED',
            eventId: req.params.eventId,
            published: req.body.published
        });
        res.json({ message: `Physical problem statements ${req.body.published ? 'published' : 'unpublished'} successfully` });
    });
});
// Set Selection Deadline
router.put('/event/:eventId/selection-deadline', (req, res) => {
    psService.setSelectionDeadline(req.params.eventId, req.body.deadline, (err) => {
        if (err) return res.status(500).json({ message: 'Failed to set deadline', error: err.message });
        broadcastEvent(req.params.eventId, {
            type: 'DEADLINE_UPDATED',
            eventId: req.params.eventId,
            deadline: req.body.deadline
        });
        res.json({ message: 'Selection deadline updated successfully' });
    });
});
// Set Physical Selection Deadline
router.put('/event/:eventId/physical-selection-deadline', (req, res) => {
    psService.setPhysicalSelectionDeadline(req.params.eventId, req.body.deadline, (err) => {
        if (err) return res.status(500).json({ message: 'Failed to set physical deadline', error: err.message });
        broadcastEvent(req.params.eventId, {
            type: 'PHYSICAL_DEADLINE_UPDATED',
            eventId: req.params.eventId,
            deadline: req.body.deadline
        });
        res.json({ message: 'Physical selection deadline updated successfully' });
    });
});
// Set Max Teams Per Statement
router.put('/event/:eventId/max-teams', (req, res) => {
    psService.setMaxTeamsPerStatement(req.params.eventId, req.body.maxTeams, (err) => {
        if (err) return res.status(500).json({ message: 'Failed to set max teams', error: err.message });
        broadcastEvent(req.params.eventId, {
            type: 'MAX_TEAMS_UPDATED',
            eventId: req.params.eventId,
            maxTeams: req.body.maxTeams
        });
        res.json({ message: 'Max teams per statement updated successfully' });
    });
});
// ========================
// TEAM: Select Problem Statement
// ========================
// GET specific team's selection
router.get('/event/:eventId/team/:teamId', (req, res) => {
    psService.getTeamSelection(req.params.eventId, req.params.teamId, (err, result) => {
        if (err) return res.status(500).json({ message: 'Failed to fetch team selection', error: err.message });
        res.json({ selection: result });
    });
});
router.post('/event/:eventId/select', (req, res) => {
    const { teamId, problemStatementId } = req.body;
    if (!teamId || !problemStatementId) {
        return res.status(400).json({ message: 'teamId and problemStatementId are required.' });
    }
    let userId = req.user?.Id || req.user?.id || null;
    let userRole = req.user?.role || req.user?.Role || null;
    const authHeader = req.headers.authorization;
    if ((!userId || !userRole) && authHeader && authHeader.startsWith('Bearer ')) {
        const token = authHeader.split(' ')[1];
        try {
            const decoded = jwt.verify(token, process.env.JWT_SECRECT || 'secret');
            userId = userId || decoded.Id || decoded.id;
            userRole = userRole || decoded.role || decoded.Role;
        } catch (e) {
            // invalid or expired token
        }
    }
    psService.selectProblemStatement(req.params.eventId, teamId, problemStatementId, userId, userRole, (err, result) => {
        if (err) {
            const status = err.status || 500;
            return res.status(status).json({ message: err.message || 'Selection failed' });
        }
        broadcastEvent(req.params.eventId, {
            type: 'SELECTION_MADE',
            eventId: req.params.eventId,
            teamId,
            problemStatementId
        });
        res.json(result);
    });
});
// ========================
// GET: All Selections for an Event
// ========================
router.get('/event/:eventId/selections', (req, res) => {
    psService.getSelectionsByEvent(req.params.eventId, (err, results) => {
        if (err) return res.status(500).json({ message: 'Failed to fetch selections', error: err.message });
        res.json({ selections: results });
    });
});
// ========================
// ADMIN: Auto-Assign Remaining Teams
// ========================
router.post('/event/:eventId/auto-assign', (req, res) => {
    const track = req.query.track || req.body?.track || null;
    psService.autoAssignRemainingTeams(req.params.eventId, track, (err, result) => {
        if (err) return res.status(500).json({ message: 'Auto-assignment failed', error: err.message });
        broadcastEvent(req.params.eventId, {
            type: 'AUTO_ASSIGN_COMPLETED',
            eventId: req.params.eventId
        });
        res.json(result);
    });
});
// ========================
// ADMIN: Reassign a Selection
// ========================
router.put('/selection/:id/reassign', (req, res) => {
    const { problemStatementId } = req.body;
    if (!problemStatementId) {
        return res.status(400).json({ message: 'problemStatementId is required.' });
    }
    psService.reassignTeamSelection(req.params.id, problemStatementId, (err, result) => {
        if (err) return res.status(500).json({ message: 'Failed to reassign selection', error: err.message });
        if (result?.selection?.EventId) {
            broadcastEvent(result.selection.EventId, {
                type: 'SELECTION_MADE',
                eventId: result.selection.EventId,
                teamId: result.selection.TeamId,
                problemStatementId
            });
        }
        res.json(result);
    });
});
// ========================
// ADMIN: Remove a Selection
// ========================
router.delete('/selection/:id', (req, res) => {
    psService.removeSelection(req.params.id, (err) => {
        if (err) return res.status(500).json({ message: 'Failed to remove selection', error: err.message });
        broadcastEvent(null, { type: 'SELECTION_REMOVED' });
        res.json({ message: 'Selection removed successfully' });
    });
});
// ========================
// PARTICIPANT-SUBMITTED PROBLEM STATEMENTS
// ========================
// GET all participant-submitted statements for an event (Admin view)
router.get('/event/:eventId/participant-statements', (req, res) => {
    psService.getParticipantStatementsByEvent(req.params.eventId, (err, results) => {
        if (err) return res.status(500).json({ message: 'Failed to fetch participant statements', error: err.message });
        res.json({ statements: results });
    });
});
// GET specific team's participant-submitted statement
router.get('/event/:eventId/team/:teamId/participant-statement', (req, res) => {
    psService.getParticipantStatementByTeam(req.params.eventId, req.params.teamId, (err, result) => {
        if (err) return res.status(500).json({ message: 'Failed to fetch team statement', error: err.message });
        res.json({ statement: result });
    });
});
// CREATE or UPDATE a participant-submitted statement (Participant/Team Lead)
router.post('/event/:eventId/participant-statement', (req, res) => {
    const { teamId, ThemeName, Category, Title, Description, TechStack, DocumentUrl, DocumentName } = req.body;
    if (!teamId || !Title || !Title.trim()) {
        return res.status(400).json({ message: 'teamId and Title are required.' });
    }
    let userId = null;
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
        const token = authHeader.split(' ')[1];
        try {
            const decoded = jwt.verify(token, process.env.JWT_SECRECT || 'secret');
            userId = decoded.Id || decoded.id;
        } catch (e) {
            // invalid token
        }
    }
    psService.upsertParticipantStatement(
        req.params.eventId,
        teamId,
        { ThemeName, Category, Title, Description, TechStack, DocumentUrl, DocumentName },
        userId,
        (err, result) => {
            if (err) {
                const status = err.status || 500;
                return res.status(status).json({ message: err.message || 'Failed to submit problem statement' });
            }
            broadcastEvent(req.params.eventId, {
                type: 'PARTICIPANT_STATEMENT_SUBMITTED',
                eventId: req.params.eventId,
                teamId
            });
            res.json(result);
        }
    );
});
// UPDATE Physical Problem Statement Format Mode (Organizer Provided vs Participant Defined)
router.put('/event/:eventId/physical-mode', (req, res) => {
    const { mode } = req.body;
    psService.updatePhysicalPSMode(req.params.eventId, mode, (err, result) => {
        if (err) {
            return res.status(500).json({ message: 'Failed to update problem statement mode', error: err.message });
        }
        broadcastEvent(req.params.eventId, {
            type: 'PHYSICAL_PS_MODE_UPDATED',
            eventId: req.params.eventId,
            mode: result.mode
        });
        res.json({ message: 'Physical problem statement format updated', mode: result.mode });
    });
});
// UPDATE status of participant-submitted statement (Admin approve / revision)
router.put('/participant-statements/:id/status', (req, res) => {
    psService.updateParticipantStatementStatus(req.params.id, req.body, (err) => {
        if (err) return res.status(500).json({ message: 'Failed to update statement status', error: err.message });
        broadcastEvent(null, { type: 'PARTICIPANT_STATEMENT_STATUS_UPDATED' });
        res.json({ message: 'Problem statement status updated successfully' });
    });
});
module.exports = router;
