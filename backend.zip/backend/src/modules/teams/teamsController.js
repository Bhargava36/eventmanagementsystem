const teamsService = require('./teamsService');
const db = require('../../config/db');
const { recordMutation } = require('../security/auditService');
const createTeam = (req, res) => {
    const {
        TeamName,
        TeamLeadEmail,
        TeamSize,
        EventId,
        MemberEmails,
        Members,
        ParticipationMode,
        TeamLeadPhoto,
        teamLeadPhoto,
        GraduationYear,
        CurrentCompany,
        Designation,
        City,
        LinkedinUrl,
        GuestCount,
        GuestNames,
        RsvpStatus
    } = req.body;
    const membersData = Members || MemberEmails;
    const leadPhoto = TeamLeadPhoto || teamLeadPhoto || null;
    teamsService.createTeam( TeamName, TeamLeadEmail, TeamSize, EventId, membersData, ParticipationMode, leadPhoto, (err, result) => {
            if (err) {
                return res.status(err.status || 500).json({
                    message: err.message
                });
            }
            const teamId = result.teamId;
            if (GraduationYear || CurrentCompany || Designation || City || LinkedinUrl || GuestCount !== undefined || GuestNames || RsvpStatus) {
                const alumniUpdateSql = `
                    UPDATE registered_teams SET
                    GraduationYear = COALESCE(?, GraduationYear),
                    CurrentCompany = COALESCE(?, CurrentCompany),
                    Designation = COALESCE(?, Designation),
                    City = COALESCE(?, City),
                    LinkedinUrl = COALESCE(?, LinkedinUrl),
                    GuestCount = COALESCE(?, GuestCount),
                    GuestNames = COALESCE(?, GuestNames),
                    RsvpStatus = COALESCE(?, RsvpStatus)
                    WHERE Id = ?
                `;
                db.query(
                    alumniUpdateSql,
                    [
                        GraduationYear || null,
                        CurrentCompany || null,
                        Designation || null,
                        City || null,
                        LinkedinUrl || null,
                        GuestCount !== undefined ? Number(GuestCount) : null,
                        GuestNames || null,
                        RsvpStatus || 'ATTENDING',
                        teamId
                    ],
                    () => {}
                );
            }
            recordMutation({
                actor: req.user,
                module: 'teams',
                action: 'CREATE_TEAM',
                entityType: 'team',
                entityId: teamId,
                eventId: EventId,
                newState: { TeamName, TeamLeadEmail, TeamSize, ParticipationMode },
                req
            });
            res.status(201).json({
                message: "Team created successfully",
                teamId: result.teamId
            });
        }
    );
};
const getAllTeams = (req, res) => {
    teamsService.getAllTeams((err, result) => {
        if (err) {
            return res.status(500).json({
                message: 'Failed to get teams',
                error: err.message
            });
        }
        res.status(200).json({
            message: 'Teams fetched successfully',
            teams: result
        });
    });
};
const getTeamById = (req, res) => {
    const id = req.params.id;
    teamsService.getTeamById(id, (err, result) => {
        if (err) {
            return res.status(500).json({
                message: 'Failed to get team by id',
                error: err.message
            });
        }
        if (result.length === 0) {
            return res.status(404).json({
                message: 'Team not found'
            });
        }
        res.status(200).json({
            message: 'Team fetched successfully',
            team: result[0]
        });
    });
};
const getTeamByCollege = (req, res) => {
    const clg = req.params.clg;
    teamsService.getTeamByCollege(clg, (err, result) => {
        if (err) {
            return res.status(500).json({
                message: 'Failed to get teams by college',
                error: err.message
            });
        }
        res.status(200).json({
            message: 'Teams fetched successfully',
            teams: result
        });
    });
};
const getTeamByState = (req, res) => {
    const state = req.params.state;
    teamsService.getTeamByState(state, (err, result) => {
        if (err) {
            return res.status(500).json({
                message: 'Failed to get teams by state',
                error: err.message
            });
        }
        res.status(200).json({
            message: 'Teams fetched successfully',
            teams: result
        });
    });
};
const getTeamByProblem = (req, res) => {
    const id = req.params.id;
    teamsService.getTeamByStatement(id, (err, result) => {
        if (err) {
            return res.status(500).json({
                message: 'Failed to get teams by problem statement',
                error: err.message
            });
        }
        res.status(200).json({
            message: 'Teams fetched successfully',
            teams: result
        });
    });
};
const getTeamByTech = (req, res) => {
    const tech = req.params.tech;
    teamsService.getTeamByTech(tech, (err, result) => {
        if (err) {
            return res.status(500).json({
                message: 'Failed to get teams by tech stack',
                error: err.message
            });
        }
        res.status(200).json({
            message: 'Teams fetched successfully',
            teams: result
        });
    });
};
const getTeamsCount = (req, res) => {
    teamsService.getTeamsCount((err, result) => {
        if (err) {
            return res.status(500).json({
                message: 'Failed to get teams count',
                error: err.message
            });
        }
        res.status(200).json({
            message: 'Teams count fetched successfully',
            count: result.teamsCount
        });
    });
};
const getMembersCount = (req, res) => {
    teamsService.getMembersCount((err, result) => {
        if (err) {
            return res.status(500).json({
                message: 'Failed to fetch members count',
                error: err.message
            });
        }
        res.status(200).json({
            message: 'Members count fetched successfully',
            count: result.registeredMembersCount || result.totalMembersCount || 0,
            registeredMembersCount: result.registeredMembersCount || 0,
            totalMembersCount: result.totalMembersCount || 0,
            uniqueMembersCount: result.uniqueMembersCount || 0
        });
    });
};
const getTeamCountByEvent = (req, res) => {
    const eventId = req.params.eventId;
    teamsService.getTeamCountByEvent(
        eventId,
        (err, result) => {
            if (err) {
                return res.status(500).json({
                    message: "Failed to get team count by event",
                    error: err.message
                });
            }
            return res.status(200).json({
                message: "Team count fetched successfully",
                count: result.teamCount
            });
        }
    );
};
const getMyTeams = (req, res) => {
    const userId = req.params.userId;
    if (!userId) {
        return res.status(400).json({
            message: 'User ID is required'
        });
    }
    teamsService.getMyTeams(userId, (err, result) => {
        if (err) {
            return res.status(500).json({
                message: 'Failed to fetch teams',
                error: err.message
            });
        }
        res.status(200).json({
            teams: result
        });
    });
};
const getTeamInfo = (req, res) => {
    const { teamId, userId } = req.params;
    if (!teamId || !userId) {
        return res.status(400).json({
            message: 'Team ID and User ID are required'
        });
    }
    teamsService.getTeamInfo(teamId, userId, (err, result) => {
        if (err) {
            console.error('Get team info error:', err);
            return res.status(500).json({
                message: 'Failed to fetch team information',
                error: err.message
            });
        }
        if (!result || !result.team) {
            return res.status(404).json({
                message: 'Team not found or user is not a member of this team'
            });
        }
        return res.status(200).json({
            message: 'Team information fetched successfully',
            team: result.team,
            members: result.members
        });
    });
};
const updateTeams = (req, res) => {
    const id = req.params.id;
    const {TeamName, TeamLeadUserId, TeamSize, College, State, ProblemStatementId, Tech_Stack, EventId} = req.body;
    if (!TeamName || !TeamLeadUserId || !TeamSize || !College || !State || !ProblemStatementId || !Tech_Stack || !EventId) {
        return res.status(400).json({
            message: 'All fields are required'
        });
    }
    if (
        Tech_Stack !== 'hardware' && Tech_Stack !== 'software') {
        return res.status(400).json({
            message: 'TechStack must be hardware or software'
        });
    }
    teamsService.updateTeamById(id, TeamName, TeamLeadUserId, TeamSize, College, State, ProblemStatementId, Tech_Stack, EventId, (err, result) => {
            if (err) {
                return res.status(500).json({
                    message: 'Team update failed',
                    error: err.message
                });
            }
            recordMutation({
                actor: req.user,
                module: 'teams',
                action: 'UPDATE_TEAM',
                entityType: 'team',
                entityId: id,
                eventId: EventId,
                newState: { TeamName, TeamLeadUserId, TeamSize, College, State, ProblemStatementId, Tech_Stack },
                req
            });
            res.status(200).json({
                message: 'Team updated successfully',
                res: result
            });
        }
    );
};
const getExportDetailsByEvent = (req, res) => {
    const EventId = req.params.eventId;
    if (!EventId) {
        return res.status(400).json({ message: "Event ID is required" });
    }
    teamsService.getExportDetailsByEvent(EventId, (err, result) => {
        if (err) {
            console.error('Export details error:', err);
            return res.status(500).json({
                message: "Failed to fetch event registration export details",
                error: err.message
            });
        }
        return res.status(200).json({
            message: "Export details fetched successfully",
            ...result
        });
    });
};

const getTeamsByEvent = (req, res) => {
    const EventId = req.params.eventId;
    teamsService.getTeamsByEvent(EventId, (err, result) => {
        if (err) {
            return res.status(500).json({
                message: "Failed to fetch teams"
            });
        }
        return res.status(200).json({
            message: "Teams fetched successfully",
            teams: result
        });
    });
};
const getPublicTeamInfo = (req, res) => {
    const { teamId } = req.params;
    if (!teamId) {
        return res.status(400).json({
            success: false,
            message: 'Team ID is required'
        });
    }
    teamsService.getPublicTeamInfo(teamId, (err, result) => {
        if (err) {
            console.error('Get public team info error:', err);
            const status = err.status || 500;
            return res.status(status).json({
                success: false,
                message: err.message || 'Failed to fetch public team information'
            });
        }
        if (!result || !result.team) {
            return res.status(404).json({
                success: false,
                message: 'Team not found'
            });
        }
        return res.status(200).json({
            success: true,
            message: 'Public team information fetched successfully',
            team: result.team,
            members: result.members
        });
    });
};
module.exports = {
    createTeam,
    getAllTeams,
    getTeamById,
    getTeamByCollege,
    getTeamByProblem,
    getTeamByState,
    getTeamByTech,
    getTeamsCount,
    getMembersCount,
    getMyTeams,
    getTeamInfo,
    getPublicTeamInfo,
    getTeamCountByEvent,
    updateTeams,
    getTeamsByEvent,
    getExportDetailsByEvent
};
